import java.time.LocalDateTime;

public class Evento {
    private int id;
    private String nome;
    private String endereco;
    private CategoriaEvento categoria;
    private LocalDateTime horario;
    private String descricao;

    public Evento(int id, String nome, String endereco, CategoriaEvento categoria, LocalDateTime horario, String descricao) {
        this.id = id;
        this.nome = nome;
        this.endereco = endereco;
        this.categoria = categoria;
        this.horario = horario;
        this.descricao = descricao;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getEndereco() { return endereco; }
    public CategoriaEvento getCategoria() { return categoria; }
    public LocalDateTime getHorario() { return horario; }
    public String getDescricao() { return descricao; }

    public String toDataString() {
        return id + ";" + nome + ";" + endereco + ";" + categoria + ";" + horario + ";" + descricao;
    }

    public static Evento fromDataString(String line) {
        String[] parts = line.split(";");
        return new Evento(
            Integer.parseInt(parts[0]),
            parts[1],
            parts[2],
            CategoriaEvento.valueOf(parts[3]),
            LocalDateTime.parse(parts[4]),
            parts[5]
        );
    }

    @Override
    public String toString() {
        return "[" + id + "] " + nome + " | " + categoria + " | " + endereco + " | " + horario + "\n" + descricao;
    }
}