import java.util.HashSet;
import java.util.Set;

public class Usuario {
    private String nome;
    private String email;
    private String cidade;
    private Set<Integer> eventosConfirmados;

    public Usuario(String nome, String email, String cidade) {
        this.nome = nome;
        this.email = email;
        this.cidade = cidade;
        this.eventosConfirmados = new HashSet<>();
    }

    public String getNome() { return nome; }

    public void confirmarEvento(int eventoId) {
        eventosConfirmados.add(eventoId);
    }

    public void cancelarEvento(int eventoId) {
        eventosConfirmados.remove(eventoId);
    }

    public boolean estaConfirmado(int eventoId) {
        return eventosConfirmados.contains(eventoId);
    }

    public Set<Integer> getEventosConfirmados() {
        return eventosConfirmados;
    }
}