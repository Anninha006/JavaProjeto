import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

public class SistemaEventos {
    private List<Evento> eventos;
    private Usuario usuario;
    private final String arquivo = "events.data";
    private int proximoId = 1;

    public SistemaEventos(Usuario usuario) {
        this.usuario = usuario;
        this.eventos = new ArrayList<>();
        carregarEventos();
    }

    private void carregarEventos() {
        try (BufferedReader br = new BufferedReader(new FileReader(arquivo))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                Evento e = Evento.fromDataString(linha);
                eventos.add(e);
                proximoId = Math.max(proximoId, e.getId() + 1);
            }
        } catch (IOException e) {
            System.out.println("Nenhum evento encontrado. Um novo arquivo será criado.");
        }
    }

    private void salvarEventos() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(arquivo))) {
            for (Evento e : eventos) {
                bw.write(e.toDataString());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Erro ao salvar os eventos.");
        }
    }

    public void cadastrarEvento(String nome, String endereco, CategoriaEvento categoria, LocalDateTime horario, String descricao) {
        Evento evento = new Evento(proximoId++, nome, endereco, categoria, horario, descricao);
        eventos.add(evento);
        salvarEventos();
        System.out.println("Evento cadastrado com sucesso!");
    }

    public void listarEventos() {
        eventos.sort(Comparator.comparing(Evento::getHorario));
        for (Evento e : eventos) {
            System.out.println(e);
        }
    }

    public void participarEvento(int id) {
        Optional<Evento> e = eventos.stream().filter(ev -> ev.getId() == id).findFirst();
        if (e.isPresent()) {
            usuario.confirmarEvento(id);
            System.out.println("Presença confirmada!");
        } else {
            System.out.println("Evento não encontrado.");
        }
    }

    public void cancelarParticipacao(int id) {
        if (usuario.estaConfirmado(id)) {
            usuario.cancelarEvento(id);
            System.out.println("Participação cancelada.");
        } else {
            System.out.println("Você não está inscrito nesse evento.");
        }
    }

    public void listarEventosConfirmados() {
        for (Evento e : eventos) {
            if (usuario.estaConfirmado(e.getId())) {
                System.out.println(e);
            }
        }
    }

    public void listarEventosOcorrendo() {
        LocalDateTime agora = LocalDateTime.now();
        for (Evento e : eventos) {
            if (e.getHorario().isBefore(agora.plusMinutes(1)) && e.getHorario().isAfter(agora.minusHours(2))) {
                System.out.println("Ocorrendo agora: " + e.getNome());
            }
        }
    }

    public void listarEventosPassados() {
        LocalDateTime agora = LocalDateTime.now();
        for (Evento e : eventos) {
            if (e.getHorario().isBefore(agora)) {
                System.out.println("Já ocorreu: " + e.getNome() + " em " + e.getHorario());
            }
        }
    }
}