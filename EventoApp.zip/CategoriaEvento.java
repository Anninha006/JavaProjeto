public enum CategoriaEvento {
    FESTA, SHOW, ESPORTE, CONFERENCIA, OUTRO
}