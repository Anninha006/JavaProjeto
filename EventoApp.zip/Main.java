import java.time.LocalDateTime;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Cadastro de Usuário ===");
        System.out.print("Nome: ");
        String nome = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Cidade: ");
        String cidade = sc.nextLine();

        Usuario usuario = new Usuario(nome, email, cidade);
        SistemaEventos sistema = new SistemaEventos(usuario);

        int opcao;
        do {
            System.out.println("\n=== MENU ===");
            System.out.println("1. Cadastrar evento");
            System.out.println("2. Listar eventos");
            System.out.println("3. Confirmar presença");
            System.out.println("4. Cancelar participação");
            System.out.println("5. Meus eventos confirmados");
            System.out.println("6. Ver eventos ocorrendo agora");
            System.out.println("7. Ver eventos passados");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    System.out.print("Nome do evento: ");
                    String enome = sc.nextLine();
                    System.out.print("Endereço: ");
                    String endereco = sc.nextLine();
                    System.out.println("Categoria (FESTA, SHOW, ESPORTE, CONFERENCIA, OUTRO): ");
                    CategoriaEvento cat = CategoriaEvento.valueOf(sc.nextLine().toUpperCase());
                    System.out.print("Data e hora (ex: 2025-05-10T20:00): ");
                    LocalDateTime dataHora = LocalDateTime.parse(sc.nextLine());
                    System.out.print("Descrição: ");
                    String desc = sc.nextLine();
                    sistema.cadastrarEvento(enome, endereco, cat, dataHora, desc);
                    break;
                case 2:
                    sistema.listarEventos();
                    break;
                case 3:
                    System.out.print("ID do evento: ");
                    int idConfirmar = sc.nextInt();
                    sistema.participarEvento(idConfirmar);
                    break;
                case 4:
                    System.out.print("ID do evento: ");
                    int idCancelar = sc.nextInt();
                    sistema.cancelarParticipacao(idCancelar);
                    break;
                case 5:
                    sistema.listarEventosConfirmados();
                    break;
                case 6:
                    sistema.listarEventosOcorrendo();
                    break;
                case 7:
                    sistema.listarEventosPassados();
                    break;
                case 0:
                    System.out.println("Saindo...");
                    break;
                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        sc.close();
    }
}